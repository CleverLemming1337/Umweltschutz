function info1() {
    alert("So haben wir Bäume gepflanzt: \n - Für jede verkaufte Tafel Schokolade wurden 0,2 Bäume gepflanzt.");
}
function info2() {
    alert("Wir haben die Einnahmen von 168 Tafeln Schokolade dafür benutzt, den Bäumen zu helfen, indem wir: \n - Sie mit Wassersäcken ausgestattet haben.");
}
function info3() {
    alert("So haben wir Geld verdient: \n - 168 Tafeln Schokolade varkauft")
}